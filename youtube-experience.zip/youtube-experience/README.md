# YouTube Experience

YouTube-style discovery site (Next.js 14, TypeScript, Tailwind) using the official YouTube Data API v3 and the official embedded player.

## Run it (5 steps)
1. Install Node.js 18.18+ (https://nodejs.org, choose LTS).
2. Open a terminal in this folder and run: `npm install`
3. Copy `.env.example` to `.env.local` and put your key: `YOUTUBE_API_KEY=your_key`
4. Run: `npm run dev`
5. Open http://localhost:3000

## Get an API key
Google Cloud Console → new project → APIs & Services → enable "YouTube Data API v3" → Credentials → Create API key. Restrict it to YouTube Data API v3 (and to your server IP when deployed). Never share it or commit `.env.local`.

## How it works
- The browser only calls `/api/search` and `/api/video`; the key is read on the server only.
- Category → query terms (per language) in `src/lib/categories.ts`. "All" with no search text uses `videos.list` chart=mostPopular (cheap). Otherwise `search.list` + one `videos.list` for duration/views.
- 10-minute server cache, per-IP rate limit (60/min), video-detail reuse, duplicate-ID removal, quota/invalid-key/network errors with clear messages.

## Limitations
- Not verified pixel-perfect against youtube.com; the logo is a simple stand-in, replace it with the official asset per YouTube's branding guidelines if you wish.
- Category results are search-based, so not perfectly categorized. Kids Cartoons uses strict SafeSearch and exclusion terms.
- Non-Islamic categories use English search terms (with relevanceLanguage set to the chosen language). Category labels are translated for English and Arabic only.
- search.list costs 100 quota units; the default 10,000/day is about 100 searches. Related videos use a title search (relatedToVideoId is no longer supported).
- No Shorts, Subscriptions, or History pages (not implemented, so not shown). The cache is in memory per server instance.
- Not yet executed: `npm install` / `npm run build` could not be run in the build environment (no network), so run `npm run build` once to confirm.
