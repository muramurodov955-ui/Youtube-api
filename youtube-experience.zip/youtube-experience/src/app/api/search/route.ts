import { NextRequest, NextResponse } from "next/server";
import { searchVideos, limited, YtError } from "@/lib/youtube";
import { CATEGORIES, catTerms } from "@/lib/categories";
import type { Lang } from "@/lib/types";

const LANGS = ["en", "ar", "uz", "tr", "ru"];
const ORDERS = ["relevance", "date", "viewCount"];
const DURS = ["any", "short", "medium", "long"];

export async function GET(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (limited(ip)) return NextResponse.json({ code: "rate" }, { status: 429 });
  const p = req.nextUrl.searchParams;
  const lang = (LANGS.includes(p.get("lang") ?? "") ? p.get("lang") : "en") as Lang;
  const cat = CATEGORIES.find((c) => c.id === p.get("cat")) ?? CATEGORIES[0];
  const user = (p.get("q") ?? "").trim().slice(0, 100);
  const order = ORDERS.includes(p.get("order") ?? "") ? p.get("order")! : "relevance";
  const dur = DURS.includes(p.get("dur") ?? "") ? p.get("dur")! : "any";
  let q = [user, catTerms(cat, lang)].filter(Boolean).join(" ");
  if (cat.kids) q += " -lecture -fatwa -sheikh"; // exclude obviously unrelated adult content
  try {
    const data = await searchVideos({ q, order, dur, lang, safe: cat.kids ? "strict" : "moderate", pageToken: p.get("pageToken") ?? undefined });
    return NextResponse.json(data);
  } catch (e) {
    const err = e instanceof YtError ? e : new YtError("upstream", 502);
    return NextResponse.json({ code: err.code }, { status: err.status });
  }
}
