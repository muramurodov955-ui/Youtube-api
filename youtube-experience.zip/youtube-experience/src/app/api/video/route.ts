import { NextRequest, NextResponse } from "next/server";
import { videoDetail, limited, YtError } from "@/lib/youtube";

export async function GET(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0] ?? "local";
  if (limited(ip)) return NextResponse.json({ code: "rate" }, { status: 429 });
  const id = req.nextUrl.searchParams.get("id") ?? "";
  if (!/^[\w-]{11}$/.test(id)) return NextResponse.json({ code: "unavailable" }, { status: 400 });
  try { return NextResponse.json(await videoDetail(id)); }
  catch (e) { const err = e instanceof YtError ? e : new YtError("upstream", 502); return NextResponse.json({ code: err.code }, { status: err.status }); }
}
