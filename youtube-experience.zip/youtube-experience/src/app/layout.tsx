import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "YouTube Experience", description: "Independent project using the YouTube Data API." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: `try{var s=JSON.parse(localStorage.getItem('yt-settings')||'{}');document.documentElement.classList.toggle('dark',s.theme!=='light');document.documentElement.lang=s.lang||'en';document.documentElement.dir=s.lang==='ar'?'rtl':'ltr'}catch(e){}` }} /></head>
      <body className="bg-white text-[#0f0f0f] dark:bg-[#0f0f0f] dark:text-white">{children}</body>
    </html>
  );
}
