"use client";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Shell from "@/components/Shell";
import { Card, Skeletons } from "@/components/VideoGrid";
import { CATEGORIES, catLabel } from "@/lib/categories";
import { errText } from "@/lib/i18n";
import { useSettings } from "@/lib/useSettings";
import type { Video } from "@/lib/types";

function Feed() {
  const sp = useSearchParams(); const router = useRouter(); const { lang, t } = useSettings();
  const q = sp.get("q") ?? "", cat = sp.get("cat") ?? "all", order = sp.get("order") ?? "relevance", dur = sp.get("dur") ?? "any";
  const [items, setItems] = useState<Video[]>([]); const [next, setNext] = useState<string>();
  const [loading, setLoading] = useState(true); const [err, setErr] = useState<string>(); const [tick, setTick] = useState(0);
  const ac = useRef<AbortController>();
  const setParam = (k: string, v: string, def: string) => { const p = new URLSearchParams(sp.toString()); v === def ? p.delete(k) : p.set(k, v); router.push("/?" + p.toString()); };

  const load = useCallback(async (token?: string) => {
    ac.current?.abort(); const c = new AbortController(); ac.current = c; setLoading(true); setErr(undefined);
    try {
      const params = new URLSearchParams({ q, cat, order, dur, lang }); if (token) params.set("pageToken", token);
      const r = await fetch("/api/search?" + params, { signal: c.signal }); const j = await r.json();
      if (!r.ok) throw new Error(j.code || "upstream");
      setItems((prev) => { const base = token ? prev : []; const seen = new Set(base.map((v) => v.id)); return [...base, ...(j.items as Video[]).filter((v) => !seen.has(v.id))]; });
      setNext(j.next);
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      if (!token) { setItems([]); setNext(undefined); } setErr((e instanceof TypeError ? "network" : (e as Error).message));
    } finally { if (ac.current === c) setLoading(false); }
  }, [q, cat, order, dur, lang]);

  useEffect(() => {
    if (cat === "custom" && !q) { ac.current?.abort(); setItems([]); setNext(undefined); setErr(undefined); setLoading(false); return; }
    load();
  }, [load, cat, q, tick]);

  const popular = !q && cat === "all";
  const sel = "h-8 rounded-lg bg-black/5 dark:bg-white/10 px-2 text-sm";
  return (
    <div>
      <div className="sticky top-14 z-10 bg-white dark:bg-[#0f0f0f] px-4 py-3 flex gap-3 overflow-x-auto no-scrollbar">
        {CATEGORIES.map((c) => (
          <button key={c.id} onClick={() => setParam("cat", c.id, "all")} aria-pressed={cat === c.id}
            className={`shrink-0 h-8 px-3 rounded-lg text-sm font-medium whitespace-nowrap ${cat === c.id ? "bg-[#0f0f0f] text-white dark:bg-white dark:text-[#0f0f0f]" : "bg-black/5 dark:bg-white/10 hover:bg-black/10 dark:hover:bg-white/20"}`}>{catLabel(c, lang)}</button>))}
      </div>
      {!popular && (
        <div className="px-4 pb-3 flex flex-wrap gap-2 items-center text-sm">
          <span className="opacity-60">{t.filtersApi}:</span>
          <select aria-label={t.sort} className={sel} value={order} onChange={(e) => setParam("order", e.target.value, "relevance")}>
            <option value="relevance" className="text-black">{t.relevance}</option><option value="date" className="text-black">{t.date}</option><option value="viewCount" className="text-black">{t.viewCount}</option></select>
          <select aria-label={t.duration} className={sel} value={dur} onChange={(e) => setParam("dur", e.target.value, "any")}>
            <option value="any" className="text-black">{t.any}</option><option value="short" className="text-black">{t.short}</option><option value="medium" className="text-black">{t.medium}</option><option value="long" className="text-black">{t.long}</option></select>
        </div>)}
      <div className="px-4 pb-8">
        {cat === "custom" && !q && <p className="py-16 text-center opacity-70">{t.customHint}</p>}
        {err && <div className="py-16 text-center"><p className="mb-4">{errText(err, t)}</p>{err !== "quota" && err !== "no_key" && <button onClick={() => setTick((x) => x + 1)} className="h-9 px-4 rounded-full bg-black/10 dark:bg-white/10">{t.retry}</button>}</div>}
        {!err && !loading && items.length === 0 && !(cat === "custom" && !q) && <p className="py-16 text-center opacity-70">{t.empty}</p>}
        <div className="grid gap-x-4 gap-y-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4">
          {items.map((v) => <Card key={v.id} v={v} />)}
          {loading && <Skeletons n={items.length ? 4 : 12} />}
        </div>
        {next && !loading && <div className="mt-8 text-center"><button onClick={() => load(next)} className="h-10 px-6 rounded-full bg-black/10 dark:bg-white/10 font-medium">{t.loadMore}</button></div>}
      </div>
    </div>);
}
export default function Page() { return <Shell><Suspense><Feed /></Suspense></Shell>; }
