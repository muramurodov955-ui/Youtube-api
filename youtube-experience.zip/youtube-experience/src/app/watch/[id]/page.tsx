"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import Shell from "@/components/Shell";
import { Card, Skeletons } from "@/components/VideoGrid";
import { errText } from "@/lib/i18n";
import { useSettings } from "@/lib/useSettings";
import { views, ago } from "@/lib/format";
import type { Video } from "@/lib/types";

type Detail = { video: Video; description: string; embeddable: boolean; channel: { title: string; avatar: string; subs: number | null } };
export default function Watch() {
  const { id } = useParams<{ id: string }>(); const router = useRouter(); const { lang, t } = useSettings();
  const [d, setD] = useState<Detail>(); const [err, setErr] = useState<string>(); const [rel, setRel] = useState<Video[]>([]);
  useEffect(() => {
    setD(undefined); setErr(undefined); setRel([]);
    fetch("/api/video?id=" + id).then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.code); setD(j); return j as Detail; })
      .then((j) => fetch("/api/search?" + new URLSearchParams({ q: j.video.title.slice(0, 80), cat: "all", lang })).then((r) => r.json()).then((s) => setRel((s.items ?? []).filter((v: Video) => v.id !== id))).catch(() => {}))
      .catch((e) => setErr(e instanceof TypeError ? "network" : e.message));
  }, [id, lang]);
  return (
    <Shell>
      <div className="p-4 flex flex-col lg:flex-row gap-6 max-w-[1700px]">
        <div className="flex-1 min-w-0">
          <button onClick={() => router.back()} className="mb-3 flex items-center gap-2 text-sm opacity-80 hover:opacity-100"><ArrowLeft size={18} className="rtl:rotate-180" />{t.back}</button>
          {err && <p className="py-16 text-center">{err === "unavailable" ? t.unavailable : errText(err, t)}</p>}
          {!d && !err && <div className="aspect-video rounded-xl bg-black/10 dark:bg-white/10 animate-pulse" />}
          {d && <>
            {d.embeddable ? <div className="aspect-video rounded-xl overflow-hidden bg-black"><iframe className="w-full h-full" src={`https://www.youtube-nocookie.com/embed/${id}?autoplay=1&rel=0`} title={d.video.title} allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; fullscreen" allowFullScreen /></div>
              : <div className="aspect-video grid place-items-center rounded-xl bg-black/10 dark:bg-white/10 text-center p-4"><div><p className="mb-3">{t.noEmbed}</p><a className="underline" target="_blank" rel="noopener noreferrer" href={`https://www.youtube.com/watch?v=${id}`}>{t.openYt}</a></div></div>}
            <h1 className="mt-3 text-xl font-bold">{d.video.title}</h1>
            <div className="mt-3 flex items-center gap-3">
              {d.channel.avatar && /* eslint-disable-next-line @next/next/no-img-element */ <img src={d.channel.avatar} alt="" className="w-10 h-10 rounded-full" />}
              <div><p className="font-medium">{d.channel.title}</p>{d.channel.subs !== null && <p className="text-xs opacity-70">{views(d.channel.subs, lang)}</p>}</div>
            </div>
            <div className="mt-4 rounded-xl bg-black/5 dark:bg-white/10 p-3 text-sm"><p className="font-medium">{views(d.video.views, lang)} {t.views} • {ago(d.video.published, lang)}</p><p className="mt-2 whitespace-pre-wrap break-words line-clamp-6">{d.description}</p></div>
          </>}
        </div>
        <aside className="lg:w-[400px] shrink-0 space-y-3">
          <h2 className="font-medium">{t.related}</h2>
          {rel.length === 0 && d && !err ? <Skeletons n={4} /> : rel.map((v) => <Card key={v.id} v={v} compact />)}
        </aside>
      </div>
    </Shell>);
}
