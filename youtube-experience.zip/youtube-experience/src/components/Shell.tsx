"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Menu, Mic, Search, Moon, Sun, Play, X, Home, BookOpen, Baby, Music2, Landmark } from "lucide-react";
import { useSettings } from "@/lib/useSettings";
import { CATEGORIES, catLabel } from "@/lib/categories";
import type { Lang } from "@/lib/types";

const SPEECH: Record<Lang, string> = { en: "en-US", ar: "ar-SA", uz: "uz-UZ", tr: "tr-TR", ru: "ru-RU" };
const QUICK = [["islamic", Landmark], ["quran", BookOpen], ["kids", Baby], ["nasheeds", Music2]] as const;

function Bar({ onMenu }: { onMenu: () => void }) {
  const { lang, theme, t, update } = useSettings();
  const router = useRouter(); const sp = useSearchParams();
  const [q, setQ] = useState(sp.get("q") ?? ""); const [mobSearch, setMobSearch] = useState(false);
  useEffect(() => setQ(sp.get("q") ?? ""), [sp]);
  const last = useRef("");
  const go = (e?: React.FormEvent) => {
    e?.preventDefault(); const v = q.trim().slice(0, 100);
    const p = new URLSearchParams(sp.toString()); v ? p.set("q", v) : p.delete("q");
    const s = "/?" + p.toString(); if (s === last.current && location.pathname === "/") return; last.current = s; router.push(s); setMobSearch(false);
  };
  const mic = () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition; if (!SR) return alert("Voice search is not supported in this browser.");
    const r = new SR(); r.lang = SPEECH[lang]; r.onresult = (e: any) => setQ(e.results[0][0].transcript); r.start();
  };
  const btn = "h-10 w-10 grid place-items-center rounded-full hover:bg-black/10 dark:hover:bg-white/10";
  return (
    <header className="fixed inset-x-0 top-0 z-30 h-14 flex items-center gap-2 px-2 sm:px-4 bg-white dark:bg-[#0f0f0f]">
      {!mobSearch && <>
        <button aria-label="Menu" onClick={onMenu} className={btn}><Menu size={22} /></button>
        <Link href="/" className="flex items-center gap-1 shrink-0"><span className="bg-[#f00] rounded-lg w-7 h-5 grid place-items-center"><Play size={11} fill="white" className="text-white" /></span><span className="font-bold tracking-tighter text-lg hidden xs:inline sm:inline">YouTube <span className="font-normal text-xs align-top opacity-60">Experience</span></span></Link>
      </>}
      <form onSubmit={go} className={`flex-1 flex items-center justify-center gap-2 ${mobSearch ? "" : "hidden sm:flex"}`}>
        {mobSearch && <button type="button" className={btn} onClick={() => setMobSearch(false)}><X size={20} /></button>}
        <div className="flex w-full max-w-[640px] h-10">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t.search} maxLength={100} className="flex-1 min-w-0 px-4 rounded-s-full border border-black/20 dark:border-white/20 bg-transparent outline-none focus:border-blue-500" />
          {q && <button type="button" aria-label="Clear" onClick={() => { setQ(""); }} className="-ms-9 me-0 w-9 grid place-items-center"><X size={18} /></button>}
          <button aria-label={t.search} className="w-16 grid place-items-center rounded-e-full border border-s-0 border-black/20 dark:border-white/20 bg-black/5 dark:bg-white/10"><Search size={20} /></button>
        </div>
        <button type="button" aria-label="Voice search" onClick={mic} className={`${btn} bg-black/5 dark:bg-white/10 shrink-0`}><Mic size={20} /></button>
      </form>
      {!mobSearch && <div className="ms-auto flex items-center gap-1">
        <button aria-label={t.search} className={`${btn} sm:hidden`} onClick={() => setMobSearch(true)}><Search size={20} /></button>
        <select aria-label="Language" value={lang} onChange={(e) => update({ lang: e.target.value as Lang })} className="h-8 rounded bg-transparent border border-black/20 dark:border-white/20 text-sm">
          {(["en", "ar", "uz", "tr", "ru"] as Lang[]).map((l) => <option key={l} value={l} className="text-black">{l.toUpperCase()}</option>)}
        </select>
        <button aria-label="Theme" onClick={() => update({ theme: theme === "dark" ? "light" : "dark" })} className={btn}>{theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}</button>
      </div>}
    </header>
  );
}

function Side({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { lang, t } = useSettings();
  const item = "flex items-center gap-5 px-3 h-10 rounded-lg hover:bg-black/10 dark:hover:bg-white/10 text-sm";
  return (
    <>
      {open && <div className="fixed inset-0 z-20 bg-black/50 md:hidden" onClick={onClose} />}
      <aside className={`fixed top-14 bottom-0 z-20 w-60 p-3 overflow-y-auto bg-white dark:bg-[#0f0f0f] start-0 ${open ? "" : "hidden"}`}>
        <Link href="/" className={item} onClick={onClose}><Home size={20} />{t.home}</Link>
        <hr className="my-3 border-black/10 dark:border-white/10" />
        <p className="px-3 pb-1 text-base font-medium">{t.quick}</p>
        {QUICK.map(([id, Icon]) => { const c = CATEGORIES.find((x) => x.id === id)!; return <Link key={id} href={`/?cat=${id}`} className={item} onClick={onClose}><Icon size={20} />{catLabel(c, lang)}</Link>; })}
        <p className="mt-6 px-3 text-xs opacity-60">{t.footer}</p>
      </aside>
    </>
  );
}

export default function Shell({ children }: { children: React.ReactNode }) {
  const { t } = useSettings();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(window.innerWidth >= 1024), []);
  return (
    <Suspense>
      <Bar onMenu={() => setOpen((o) => !o)} />
      <Side open={open} onClose={() => window.innerWidth < 768 && setOpen(false)} />
      <main className={`pt-14 min-h-screen ${open ? "md:ps-60" : ""}`}>
        {children}
        <footer className="px-4 py-6 text-xs opacity-60">{t.footer}</footer>
      </main>
    </Suspense>
  );
}
