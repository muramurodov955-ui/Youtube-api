"use client";
import Link from "next/link";
import type { Video } from "@/lib/types";
import { dur, views, ago } from "@/lib/format";
import { useSettings } from "@/lib/useSettings";

export function Skeletons({ n = 12 }: { n?: number }) {
  return <>{Array.from({ length: n }).map((_, i) => (
    <div key={i} className="animate-pulse"><div className="aspect-video rounded-xl bg-black/10 dark:bg-white/10" />
      <div className="flex gap-3 mt-3"><div className="w-9 h-9 rounded-full bg-black/10 dark:bg-white/10" /><div className="flex-1 space-y-2"><div className="h-4 rounded bg-black/10 dark:bg-white/10" /><div className="h-3 w-2/3 rounded bg-black/10 dark:bg-white/10" /></div></div></div>))}</>;
}

export function Card({ v, compact }: { v: Video; compact?: boolean }) {
  const { lang, t } = useSettings();
  const meta = `${views(v.views, lang)} ${t.views} • ${ago(v.published, lang)}`;
  const thumb = (
    <div className={`relative aspect-video overflow-hidden rounded-xl bg-black/10 dark:bg-white/10 ${compact ? "w-40 shrink-0" : ""}`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={v.thumb} alt="" loading="lazy" className="w-full h-full object-cover" />
      {v.duration && <span className="absolute bottom-1 end-1 rounded bg-black/80 px-1 text-xs font-medium text-white">{dur(v.duration)}</span>}
    </div>);
  return (
    <Link href={`/watch/${v.id}`} className={compact ? "flex gap-2" : "block"}>
      {thumb}
      <div className={compact ? "min-w-0" : "mt-3 flex gap-3"}>
        {!compact && <div className="w-9 h-9 shrink-0 rounded-full bg-black/10 dark:bg-white/10 grid place-items-center text-sm font-medium">{v.channel[0]}</div>}
        <div className="min-w-0"><h3 className={`font-medium leading-snug line-clamp-2 ${compact ? "text-sm" : "text-base"}`}>{v.title}</h3>
          <p className="mt-1 text-sm opacity-70 truncate">{v.channel}</p><p className="text-sm opacity-70">{meta}</p></div>
      </div>
    </Link>);
}
