import type { Lang } from "./types";
type Q = { en: string } & Partial<Record<Lang, string>>;
export type Cat = { id: string; label: Q; q: Q; kids?: boolean };
export const CATEGORIES: Cat[] = [
  { id: "all", label: { en: "All", ar: "الكل", uz: "Hammasi", tr: "Tümü", ru: "Все" }, q: { en: "" } },
  { id: "islamic", label: { en: "Islamic Videos", ar: "فيديوهات إسلامية" }, q: { en: "Islamic reminders Quran Hadith", ar: "تذكير إسلامي قرآن حديث", uz: "islomiy eslatmalar Qur'on hadis", tr: "İslami hatırlatmalar Kuran hadis", ru: "исламские напоминания Коран хадис" } },
  { id: "kids", kids: true, label: { en: "Islamic Kids Cartoons", ar: "كرتون إسلامي للأطفال" }, q: { en: "Islamic cartoons for kids Muslim kids animation", ar: "كرتون إسلامي للأطفال رسوم متحركة", uz: "bolalar uchun islomiy multfilm", tr: "çocuklar için İslami çizgi film", ru: "исламские мультфильмы для детей" } },
  { id: "quran", label: { en: "Quran Recitation", ar: "تلاوة القرآن" }, q: { en: "Quran recitation surah", ar: "تلاوة القرآن الكريم سورة", uz: "Qur'on tilovati sura", tr: "Kuran tilaveti sure", ru: "чтение Корана сура" } },
  { id: "lectures", label: { en: "Islamic Lectures", ar: "محاضرات إسلامية" }, q: { en: "Islamic lecture", ar: "محاضرة إسلامية", uz: "islomiy ma'ruza", tr: "İslami konferans", ru: "исламская лекция" } },
  { id: "nasheeds", label: { en: "Nasheeds", ar: "أناشيد" }, q: { en: "nasheed vocals only", ar: "أناشيد إسلامية", uz: "nashida", tr: "ilahi nasheed", ru: "нашид" } },
  { id: "stories", label: { en: "Islamic Stories", ar: "قصص إسلامية" }, q: { en: "Islamic stories", ar: "قصص إسلامية", uz: "islomiy hikoyalar", tr: "İslami hikayeler", ru: "исламские истории" } },
  { id: "prophets", label: { en: "Prophets' Stories", ar: "قصص الأنبياء" }, q: { en: "stories of the prophets", ar: "قصص الأنبياء", uz: "payg'ambarlar qissalari", tr: "peygamber kıssaları", ru: "истории пророков" } },
  { id: "education", label: { en: "Educational Videos", ar: "فيديوهات تعليمية" }, q: { en: "educational video lesson" } },
  { id: "science", label: { en: "Science", ar: "علوم" }, q: { en: "science explained" } },
  { id: "tech", label: { en: "Technology", ar: "تقنية" }, q: { en: "technology news review" } },
  { id: "gaming", label: { en: "Gaming", ar: "ألعاب" }, q: { en: "gaming gameplay" } },
  { id: "entertainment", label: { en: "Entertainment", ar: "ترفيه" }, q: { en: "entertainment" } },
  { id: "sports", label: { en: "Sports", ar: "رياضة" }, q: { en: "sports highlights" } },
  { id: "music", label: { en: "Music", ar: "موسيقى" }, q: { en: "music" } },
  { id: "news", label: { en: "News", ar: "أخبار" }, q: { en: "news today" } },
  { id: "custom", label: { en: "Custom Search", ar: "بحث مخصص" }, q: { en: "" } },
];
export const catLabel = (c: Cat, l: Lang) => c.label[l] ?? c.label.en;
export const catTerms = (c: Cat, l: Lang) => c.q[l] ?? c.q.en;
