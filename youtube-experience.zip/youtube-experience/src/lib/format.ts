export function dur(iso: string) {
  const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(iso); if (!m) return "";
  const [h, mi, s] = [Number(m[1] ?? 0), Number(m[2] ?? 0), Number(m[3] ?? 0)];
  const p = (n: number) => String(n).padStart(2, "0");
  return h ? `${h}:${p(mi)}:${p(s)}` : `${mi}:${p(s)}`;
}
export const views = (n: number, lang: string) => new Intl.NumberFormat(lang, { notation: "compact" }).format(n);
export function ago(iso: string, lang: string) {
  const s = (new Date(iso).getTime() - Date.now()) / 1000; const f = new Intl.RelativeTimeFormat(lang, { numeric: "auto" });
  for (const [u, n] of [["year", 31536000], ["month", 2592000], ["week", 604800], ["day", 86400], ["hour", 3600], ["minute", 60]] as const)
    if (Math.abs(s) >= n) return f.format(Math.round(s / n), u);
  return f.format(0, "second");
}
