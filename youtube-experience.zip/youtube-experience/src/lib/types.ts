export type Video = { id: string; title: string; channel: string; channelId: string; thumb: string; published: string; views: number; duration: string };
export type Lang = "en" | "ar" | "uz" | "tr" | "ru";
