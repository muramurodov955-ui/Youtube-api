"use client";
import { useCallback, useEffect, useState } from "react";
import type { Lang } from "./types";
import { I18N } from "./i18n";
type S = { lang: Lang; theme: "dark" | "light" };
export function useSettings() {
  const [s, setS] = useState<S>({ lang: "en", theme: "dark" });
  useEffect(() => {
    const read = () => { try { const v = localStorage.getItem("yt-settings"); if (v) setS(JSON.parse(v)); } catch {} };
    read(); window.addEventListener("yt-settings", read); return () => window.removeEventListener("yt-settings", read);
  }, []);
  useEffect(() => {
    document.documentElement.lang = s.lang; document.documentElement.dir = s.lang === "ar" ? "rtl" : "ltr";
    document.documentElement.classList.toggle("dark", s.theme === "dark");
  }, [s]);
  const update = useCallback((p: Partial<S>) => {
    const n = { ...s, ...p };
    try { localStorage.setItem("yt-settings", JSON.stringify(n)); } catch {}
    window.dispatchEvent(new Event("yt-settings"));
  }, [s]);
  return { ...s, t: I18N[s.lang], update };
}
