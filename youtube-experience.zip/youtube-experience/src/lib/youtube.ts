// Server-only module: the API key never leaves the server.
import type { Video } from "./types";
const BASE = "https://www.googleapis.com/youtube/v3";
export class YtError extends Error { constructor(public code: string, public status: number) { super(code); } }

const cache = new Map<string, { t: number; v: unknown }>();
const TTL = 10 * 60 * 1000;
async function cached<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.t < TTL) return hit.v as T;
  const v = await fn();
  if (cache.size > 500) cache.delete(cache.keys().next().value as string);
  cache.set(key, { t: Date.now(), v });
  return v;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
async function yt(path: string, params: Record<string, string | undefined>): Promise<any> {
  const key = process.env.YOUTUBE_API_KEY;
  if (!key || key.includes("YOUR_API_KEY")) throw new YtError("no_key", 500);
  const url = new URL(BASE + path);
  for (const [k, v] of Object.entries(params)) if (v) url.searchParams.set(k, v);
  url.searchParams.set("key", key);
  let res: Response;
  try { res = await fetch(url, { cache: "no-store" }); } catch { throw new YtError("network", 502); }
  if (!res.ok) {
    const j = await res.json().catch(() => null);
    const reason = j?.error?.errors?.[0]?.reason as string | undefined;
    if (reason && /quota|limit/i.test(reason)) throw new YtError("quota", 429);
    if (res.status === 400 || res.status === 403) throw new YtError("invalid_key", res.status);
    throw new YtError("upstream", 502);
  }
  return res.json();
}

const videoCache = new Map<string, Video>();
const mapVideo = (i: any): Video => ({
  id: i.id, title: i.snippet.title, channel: i.snippet.channelTitle, channelId: i.snippet.channelId,
  thumb: i.snippet.thumbnails?.high?.url || i.snippet.thumbnails?.medium?.url || "",
  published: i.snippet.publishedAt, views: Number(i.statistics?.viewCount ?? 0), duration: i.contentDetails?.duration ?? "",
});

async function details(ids: string[]): Promise<Video[]> {
  const missing = ids.filter((id) => !videoCache.has(id));
  if (missing.length) {
    const j = await yt("/videos", { part: "snippet,contentDetails,statistics", id: missing.join(",") });
    for (const i of j.items ?? []) videoCache.set(i.id, mapVideo(i));
    if (videoCache.size > 2000) videoCache.clear();
  }
  return ids.map((id) => videoCache.get(id)).filter(Boolean) as Video[];
}

export type SearchArgs = { q: string; order: string; dur: string; lang: string; safe: string; pageToken?: string };
export function searchVideos(a: SearchArgs) {
  return cached(JSON.stringify(a), async () => {
    const ids: string[] = [];
    let next: string | undefined;
    if (!a.q) { // "All" without query: most popular chart (cheap, 1 quota unit)
      const j = await yt("/videos", { part: "snippet,contentDetails,statistics", chart: "mostPopular", regionCode: "US", maxResults: "24", pageToken: a.pageToken });
      for (const i of j.items ?? []) { videoCache.set(i.id, mapVideo(i)); ids.push(i.id); }
      next = j.nextPageToken;
    } else {
      const j = await yt("/search", { part: "snippet", type: "video", q: a.q, maxResults: "24", order: a.order, videoDuration: a.dur === "any" ? undefined : a.dur, relevanceLanguage: a.lang, safeSearch: a.safe, videoEmbeddable: "true", pageToken: a.pageToken });
      for (const i of j.items ?? []) if (i.id?.videoId) ids.push(i.id.videoId);
      next = j.nextPageToken;
    }
    return { items: await details([...new Set(ids)]), next };
  });
}

export function videoDetail(id: string) {
  return cached("v:" + id, async () => {
    const j = await yt("/videos", { part: "snippet,contentDetails,statistics,status", id });
    const i = j.items?.[0];
    if (!i) throw new YtError("unavailable", 404);
    const ch = await yt("/channels", { part: "snippet,statistics", id: i.snippet.channelId }).catch(() => null);
    const c = ch?.items?.[0];
    return {
      video: mapVideo(i), description: i.snippet.description as string, embeddable: i.status?.embeddable !== false,
      channel: { title: i.snippet.channelTitle as string, avatar: (c?.snippet?.thumbnails?.default?.url as string) ?? "", subs: c?.statistics?.hiddenSubscriberCount ? null : Number(c?.statistics?.subscriberCount ?? 0) },
    };
  });
}

const hits = new Map<string, number[]>();
export function limited(ip: string) { // 60 requests / minute / IP
  const now = Date.now(); const arr = (hits.get(ip) ?? []).filter((t) => now - t < 60000);
  arr.push(now); hits.set(ip, arr); return arr.length > 60;
}
